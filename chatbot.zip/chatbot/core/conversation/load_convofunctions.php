<?php

/***************************************
 * http://www.program-o.com
 * PROGRAM O
 * Version: 2.6.8
 * FILE: chatbot/core/aiml/load_convofunctions.php
 * AUTHOR: Elizabeth Perreau and Dave Morton
 * DATE: MAY 17TH 2014
 * DETAILS: this file contains all the includes that are needed to process the return/display of the conversation
 ***************************************/
include_once("intialise_conversation.php");
include_once("display_conversation.php");
include_once("make_conversation.php");

runDebug(__FILE__, __FUNCTION__, __LINE__, "Convofunction include files loaded", 4);